const React = require('react')
const ReactDOM = require('react-dom')

class Footer extends React.Component {
  render() {
    return (
      <div className="ui grid stackable padded SiteFooter">
        <div className="column sixteen wide">
        </div>
      </div>
    )
  }
}

module.exports = Footer
